from pathlib import Path
import csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1]
for d in ['figures','data']:(R/d).mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
def fig(name):
 for ext in ['pdf','svg']:plt.savefig(R/'figures'/f'{name}.{ext}',bbox_inches='tight')
 plt.close()
def table(name,caption,heads,widths,rows,source):
 spec='@{}'+''.join(r'>{\raggedright\arraybackslash}p{'+str(w)+'mm}' for w in widths)+'@{}'
 head=' & '.join(heads)+r' \\'+'\n'
 s=r'\begingroup\small'+'\n'+r'\begin{longtable}{'+spec+'}\n'+r'\caption{'+caption+'}'+r'\label{tab:'+name+r'}\\'+'\n'+r'\toprule'+'\n'+head+r'\midrule\endfirsthead'+'\n'+r'\multicolumn{'+str(len(heads))+r'}{l}{Tableau \thetable{} --- suite}\\'+'\n'+r'\toprule'+'\n'+head+r'\midrule\endhead\bottomrule\endfoot'+'\n'
 s+='\n'.join(' & '.join(str(v) for v in row)+r' \\' for row in rows)
 s+='\n'+r'\end{longtable}\endgroup'+'\n'+r'\source{'+source+'}\n'
 (R/'data'/f'{name}.tex').write_text(s)
def fr(x,n=2):return f'{x:.{n}f}'.replace('.',',')
walker=[('Standard',.11,27.6,220),('Précomprimé',.22,19.2,120),('Demi-bottes',.087,10.9,140),('Sans broches',.077,11.7,165),('Enduit chaux',5.62,41.1,55)]
with (R/'data/walker_2004.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['configuration','K_axial_kN_mm','F_max_kN','tassement_au_max_mm','source']);w.writerows([list(r)+['Walker 2004 tableau 2 PDF p7'] for r in walker])
table('walker','Résultats des cinq murs de Walker (2004).',['Configuration',r'Raideur axiale\newline (kN/mm)',r'Force maximale\newline (kN)',r'Tassement au\newline maximum (mm)','Mode observé'],[31,27,26,29,38],[[n,fr(k,3),fr(f,1),v,'Flambement global' if i<4 else 'Décollement sous lisse'] for i,(n,k,f,v) in enumerate(walker)],r'Walker (2004), tableau 2 et discussion, p.~7--9 du PDF. Un mur par configuration ; tassement vertical, non flèche latérale.')
table('ratios','Rapports descriptifs par rapport au mur standard de Walker.',['Configuration',r'Rapport des\newline raideurs axiales',r'Rapport des\newline forces maximales'],[57,46,46],[[n,fr(k/.11),fr(f/27.6)] for n,k,f,v in walker[1:]],r'Calculs sur le tableau 2 de Walker (2004). Les configurations modifient plusieurs paramètres ; pas de répétitions permettant un effet statistique.')
figu,axs=plt.subplots(1,2,figsize=(8,3.3));labels=[x[0] for x in walker];y=np.arange(5)
axs[0].barh(y,[x[2] for x in walker],color=['#667a82']*4+['#ba8544']);axs[0].set_yticks(y,labels);axs[0].invert_yaxis();axs[0].set_xlabel('Force maximale (kN)')
axs[1].barh(y,[x[1] for x in walker],color=['#667a82']*4+['#ba8544']);axs[1].set_yticks(y,[]);axs[1].invert_yaxis();axs[1].set_xscale('log');axs[1].set_xlabel('Raideur axiale (kN/mm) — échelle log')
for ax in axs:ax.grid(axis='x',alpha=.2);ax.set_axisbelow(True)
figu.tight_layout();fig('walker')
# Paires transcrites des tableaux 1 à 8 du rapport primaire, sans extrapolation.
don={1:([0,.03,.09,.22,.31,.56,1.09,2.63,4.72,5.97],[0,31,83,114,130,156,182,234,250,260]),2:([0,.06,.09,.12,.16,.22,.28,.44,.97,2,3.09,5.19],[0,21,42,52,62,73,83,104,156,208,260,343]),3:([0,.06,.09,.12,.16,.28,.44],[0,78,83,88,99,114,135]),4:([0,.06,.12,.19,.31,1],[0,62,78,109,125,125]),5:([0,.09,.62,1.56,3.06,4.44,4.94,7.25,8.81],[0,42,83,114,130,151,161,187,208]),6:([0,.72,.91,1.81,2.97,3.41,4.06,6,7.63,8],[0,73,83,99,146,156,177,208,239,250]),7:([0,.06,.09,.16,.56,1.97,4.47,6.81],[0,42,62,73,104,125,156,172]),8:([0,.06,.19,.5,.94,1.5,2.66],[0,42,52,62,73,83,94])}
with (R/'data/donahue_2003.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['essai','fleche_in','pression_psf','fleche_mm','pression_kPa','source'])
 for n,(xx,yy) in don.items():
  for x,y in zip(xx,yy):w.writerow([n,x,y,x*25.4,y*.04788025898,f'Donahue 2003 essai {n} PDF p{n+3}'])
configs=[['1','Ciment, 25,4 mm','Treillis soudé','Agrafes et vis en tête et pied'],['2','Ciment, 25,4 mm','Grillage hexagonal','Agrafes et vis ; lisses différentes'],['3','Ciment, 25,4 mm','Fibres acier 1 \\%','Vis en tête et pied'],['4','Ciment, 25,4 mm','Fibres acier 0,8 \\%','Appui latéral en tête ; treillis en pied'],['5','Terre, 50,8 mm','Treillis plastique','Liens traversants à chaque rang'],['6','Terre, 50,8 mm','Treillis plastique','Liens traversants aux tiers'],['7','Terre, 50,8 mm','Treillis plastique','Agrafage ; sans liens traversants'],['8','Sans enduit','Treillis soudé','Agrafage en tête et pied']]
table('don_config','Configurations des huit essais hors plan de Donahue.',['Essai',r'Parement\newline (par face)','Renfort','Liaisons distinctives'],[12,36,36,64],configs,r'Donahue (2003), fiches des essais 1 à 8, p.~4--11 du PDF. Descriptions abrégées : les détails complets restent nécessaires pour reproduire les essais.')
notes={1:'Rupture signalée à 270 psf (12,93 kPa)',2:'Pas de rupture au dernier point',3:'Rupture brusque à 146 psf (6,99 kPa)',4:'Palier à 125 psf ; statut final non précisé',5:'Rupture non renseignée dans le tableau',6:'Dégradation haute à 151 psf ; rupture à 270 psf',7:'Rupture non renseignée dans le tableau',8:'Rupture signalée à 104 psf (4,98 kPa)'}
table('don_result','Derniers points enregistrés et ruptures signalées : deux informations distinctes.',['Essai',r'Dernière pression\newline (kPa)',r'Flèche associée\newline (mm)','Observation de la source'],[12,33,31,71],[[n,fr(v[1][-1]*.04788025898),fr(v[0][-1]*25.4,1),notes[n]] for n,v in don.items()],r'Donahue (2003), tableaux des essais. Les flèches associées aux ruptures signalées au-delà du dernier point ne sont pas connues ; aucune paire fictive n’est ajoutée.')
figu,axs=plt.subplots(1,2,figsize=(8,3.8))
for ax,group in zip(axs,[range(1,5),range(5,9)]):
 for n in group:
  x,y=don[n];ax.plot(np.array(x)*25.4,np.array(y)*.04788025898,'o-',ms=3,lw=1.3,label=f'Essai {n}')
 ax.set_xlabel('Flèche à mi-hauteur (mm)');ax.set_ylabel('Pression hors plan (kPa)');ax.grid(alpha=.2);ax.legend(frameon=False,fontsize=8);ax.set_ylim(0,18)
axs[0].set_title('Enduits ciment : essais 1 à 4');axs[1].set_title('Terre : 5 à 7 ; sans enduit : 8');figu.tight_layout();fig('donahue')
x=np.linspace(0,.9,181);a=1/(1-x);plt.figure(figsize=(6.7,3.5));plt.plot(x,a,color='#326778',lw=2);plt.xlabel(r'Charge normalisée $N/N_E$');plt.ylabel(r'Amplification idéale $a/a_0$');plt.grid(alpha=.2);plt.ylim(0,11);fig('amplification')
with (R/'data/euler_ideal.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['N_sur_NE','a_sur_a0']);w.writerows(zip(x,a))
table('mecanismes','Phénomènes à distinguer dans les sources.',['Phénomène','Chargement ou cause','Observation déterminante'],[37,51,61],[['Flambement global','Compression verticale avec défaut latéral','Déformée globale amplifiée ; vérifier les appuis et la rotation des lisses'],['Instabilité locale du parement','Compression d’une peau insuffisamment maintenue','Bombement local, pli ou décollement ; longueur libre à identifier'],['Flexion hors plan','Pression latérale ou force transversale','Flèche et courbure ; peut exister sans charge verticale ajoutée'],['Écrasement ou rupture de liaison','Contrainte locale ou transmission insuffisante','Rupture du matériau, glissement ou arrachement, sans nécessaire instabilité globale'],['Flambement des tiges','Flexion et ovalisation d’une tige végétale','Mécanisme microscopique ; pas une charge critique de mur']],r'Classification mécanique utilisée dans ce rapport ; chaque observation doit être reliée au protocole de sa source.')
table('vardy','Plan expérimental de Vardy et MacDougall (2013).',['Groupe',r'Hauteur\newline (m)',r'Excentricité\newline (mm)',r'Nombre\newline de murs','Observation à retenir'],[24,25,29,22,47],[['C1', '0,33','0','3','Compression des parements'],['C3','1,05','0','3','Pas de flambement global observé avant le pic'],['E1','0,33','120','3','Compression excentrée ; déformations dissymétriques'],['E3','1,05','120','3','Flexion accrue ; rupture comprimée puis fissure tendue']],r'Vardy et MacDougall (2013), tableau 1 et figures 5--14. C33 n’a pas de données de déplacement exploitables dans la courbe correspondante.')
print('6 tableaux, 3 figures, 3 CSV générés.')
