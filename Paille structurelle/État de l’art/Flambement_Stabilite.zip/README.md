# Flambement et stabilité hors plan des murs en paille porteuse

État de l’art — Julie Lossignol — 17 novembre 2026.

Le rapport distingue le flambement global, les instabilités locales des parements et la flexion hors plan. Les résultats personnels de 2023 sont exclus et feront l’objet d’un article distinct. Les dispositions réglementaires historiques sont présentées avec leur date et leur périmètre.

## Contenu

- `Flambement_Stabilite.tex` : document principal.
- `chapitres/` : texte et références.
- `data/` : six tableaux LaTeX et trois fichiers CSV, avec provenance des données.
- `figures/` : trois figures aux formats PDF et SVG.
- `scripts/generer.py` : reproduction des tableaux, figures et données dérivées.

Les PDF et documents des auteurs cités ne sont pas redistribués dans cette archive. Les tableaux transcrits ne doivent pas être interprétés comme des valeurs de dimensionnement.

## Compilation

Avec Python 3, NumPy, Matplotlib et une installation LaTeX comprenant XeLaTeX et latexmk :

```bash
python3 scripts/generer.py
latexmk -xelatex -interaction=nonstopmode -halt-on-error Flambement_Stabilite.tex
```

La mise en page réserve de la place après chaque titre et empêche la coupure d’un premier paragraphe avant ses cinq premières lignes.
